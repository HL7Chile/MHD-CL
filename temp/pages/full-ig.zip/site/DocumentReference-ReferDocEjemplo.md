# HL7.FHIR.CL.MHDIG\Referencia documental mínima para DocumentoArg - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Referencia documental mínima para DocumentoArg**

## Example DocumentReference: Referencia documental mínima para DocumentoArg

Perfil: [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md)

**masterIdentifier**: Identifier type for XDS UniqueId/IPS-ARG-2026-00001

**status**: Current

**type**: Summary of episode note

**category**: Resumen clínico de paciente

**subject**: [Pablo Fernandez Perez(official) Male, DoB: 1912-06-12 ( https://www.registrocivil.cl/run#99999999-9 (use: official))](Bundle-BundleDocumentoIpsEjemplo.md#urn-uuid-991a7102-d221-498d-9157-c4192934e3b7)

**date**: 2026-07-06 10:30:00-0300

**author**: [María Laura Gómez (official) (RNPI: 987654 (use: usual))](Practitioner-PrestadorCLInline.md)

> **content**

### Attachments

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| - | **ContentType** | **Url** | **Title** | **Creation** |
| * | application/fhir+json | Bundle-BundleDocumentoIpsEjemplo.json | Documento IPS Chileno mínimo | 2026-07-06 10:30:00-0300 |


### Contexts

| | |
| :--- | :--- |
| - | **Period** |
| * | 2026-07-06 10:30:00-0300 --> (ongoing) |



## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "ReferDocEjemplo",
  "meta" : {
    "profile" : ["https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ReferenciaDocumental"]
  },
  "masterIdentifier" : {
    "type" : {
      "coding" : [{
        "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
        "code" : "uniqueId"
      }]
    },
    "system" : "https://repositorio.hsi.ar/documentos/ips",
    "value" : "IPS-ARG-2026-00001"
  },
  "status" : "current",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "34133-9",
      "display" : "Summary of episode note"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "60591-5"
    }],
    "text" : "Resumen clínico de paciente"
  }],
  "subject" : {
    "reference" : "urn:uuid:991a7102-d221-498d-9157-c4192934e3b7"
  },
  "date" : "2026-07-06T10:30:00-03:00",
  "author" : [{
    "reference" : "Practitioner/PrestadorCLInline"
  }],
  "content" : [{
    "attachment" : {
      "contentType" : "application/fhir+json",
      "url" : "Bundle-BundleDocumentoIpsEjemplo.json",
      "title" : "Documento IPS Chileno mínimo",
      "creation" : "2026-07-06T10:30:00-03:00"
    }
  }],
  "context" : {
    "period" : {
      "start" : "2026-07-06T10:30:00-03:00"
    }
  }
}

```
