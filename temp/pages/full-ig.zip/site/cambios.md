# HL7.FHIR.CL.MHDIG\Historial de Versiones - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **Historial de Versiones**

## Historial de Versiones

### Versión 0.1.0

Se crea la primera adaptación nacional de MHD.

