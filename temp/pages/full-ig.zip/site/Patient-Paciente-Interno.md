# HL7.FHIR.CL.MHDIG\Paciente-Interno - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Paciente-Interno**

## Example Patient: Paciente-Interno

Perfil: [Paciente](https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-Paciente-cl-ips.html)

Pablo Fernandez Perez(official) Male, DoB: 1912-06-12 ( https://www.registrocivil.cl/run#99999999-9 (use: official))

-------

| | |
| :--- | :--- |
| Active: | true |
| Contact Detail | ph: 1141233100 |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "Paciente-Interno",
  "meta" : {
    "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Paciente-cl-ips"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://www.registrocivil.cl/run",
    "value" : "99999999-9"
  }],
  "active" : true,
  "name" : [{
    "use" : "official",
    "text" : "Pablo Fernandez Perez",
    "family" : "Fernandez",
    "_family" : {
      "extension" : [{
        "url" : "https://hl7chile.cl/fhir/ig/clcore/StructureDefinition/SegundoApellido",
        "valueString" : "Perez"
      }]
    },
    "given" : ["Pablo"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "1141233100"
  }],
  "gender" : "male",
  "birthDate" : "1912-06-12"
}

```
