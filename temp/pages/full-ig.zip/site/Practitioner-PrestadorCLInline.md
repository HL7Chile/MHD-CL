# HL7.FHIR.CL.MHDIG\PrestadorCLInline - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PrestadorCLInline**

## Example Practitioner: PrestadorCLInline

Perfil: [Prestador Individual](https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-Prestador-cl-ips.html)

María Laura Gómez (official) (RNPI: 987654 (use: usual))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Active: | true | Gender: | Female |
| Date of Birth: | 1980-05-12 | | |
| Other Id: | RUN/12345678-K (use: official) | | |
| Contact Detail | * [+56 9 5555-1234](tel:+5695555-1234)
* [maria.perez@example.org](mailto:maria.perez@example.org)
 | | |
| Qualification: | Médica* Identifier: cert
 | | |



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "PrestadorCLInline",
  "meta" : {
    "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Prestador-cl-ips"]
  },
  "identifier" : [{
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "https://hl7chile.cl/fhir/ig/clcore/CodeSystem/CSTipoIdentificador",
        "code" : "01"
      }]
    },
    "system" : "https://www.registrocivil.cl/run",
    "value" : "12345678-K"
  },
  {
    "use" : "usual",
    "type" : {
      "coding" : [{
        "system" : "https://hl7chile.cl/fhir/ig/clcore/CodeSystem/CSTipoIdentificador",
        "code" : "13"
      }]
    },
    "system" : "https://rnpi.superdesalud.gob.cl/#",
    "value" : "987654"
  }],
  "active" : true,
  "name" : [{
    "use" : "official",
    "family" : "Gómez",
    "_family" : {
      "extension" : [{
        "url" : "https://hl7chile.cl/fhir/ig/clcore/StructureDefinition/SegundoApellido",
        "valueString" : "Perez"
      }]
    },
    "given" : ["María", "Laura"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+56 9 5555-1234",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "maria.perez@example.org",
    "use" : "work"
  }],
  "gender" : "female",
  "birthDate" : "1980-05-12",
  "qualification" : [{
    "identifier" : [{
      "value" : "cert"
    }],
    "code" : {
      "text" : "Médica"
    }
  }]
}

```
