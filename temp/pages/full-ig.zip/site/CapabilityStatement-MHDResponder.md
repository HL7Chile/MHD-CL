# HL7.FHIR.CL.MHDIG\MHD Responder - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MHD Responder**

## CapabilityStatement: MHD Responder 

| | |
| :--- | :--- |
| *Official URL*:https://hl7chile.cl/fhir/ig/mhd/CapabilityStatement/MHDResponder | *Version*:0.1.0 |
| Draft as of 2026-09-02 | *Computable Name*:MHDResponder |
| *Other Identifiers:*OID:2.16.840.1.113883.2.22.40.14.13.2 | |

 
CapabilityStatement que define las capacidades requeridas para un servidor MHD conforme a la Guía MHD para HSI. 
El servidor implementa las funciones de Document Recipient y Document Responder definidas por IHE MHD 4.2.2, adaptadas a los perfiles locales de esta guía. 

 [Raw OpenAPI-Swagger Definition file](MHDResponder.openapi.json) | [Download](MHDResponder.openapi.json) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "MHDResponder",
  "url" : "https://hl7chile.cl/fhir/ig/mhd/CapabilityStatement/MHDResponder",
  "version" : "0.1.0",
  "name" : "MHDResponder",
  "title" : "MHD Responder",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-09-02",
  "publisher" : "Hl7 Chile",
  "contact" : [{
    "name" : "Hl7 Chile",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7chile.cl/"
    }]
  }],
  "description" : "CapabilityStatement que define las capacidades requeridas para un servidor\nMHD conforme a la Guía MHD para HSI.\n\nEl servidor implementa las funciones de Document Recipient y Document\nResponder definidas por IHE MHD 4.2.2, adaptadas a los perfiles locales\nde esta guía.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "kind" : "requirements",
  "instantiates" : ["https://profiles.ihe.net/ITI/MHD/CapabilityStatement/IHE.MHD.DocumentRecipient",
  "https://profiles.ihe.net/ITI/MHD/CapabilityStatement/IHE.MHD.DocumentResponder"],
  "fhirVersion" : "4.0.1",
  "format" : ["application/fhir+json", "application/fhir+xml"],
  "implementationGuide" : ["https://hl7chile.cl/fhir/ig/mhd/ImplementationGuide/hl7.fhir.cl.mhdig"],
  "rest" : [{
    "mode" : "server",
    "documentation" : "Servidor MHD local que permite registrar, consultar y recuperar\ndocumentos clínicos utilizando las transacciones definidas por\nIHE MHD y los perfiles definidos por esta guía.",
    "security" : {
      "description" : "Las transacciones deben realizarse mediante HTTPS y aplicar los\nmecanismos de autenticación, autorización, control de acceso,\nauditoría y trazabilidad definidos para la infraestructura."
    },
    "resource" : [{
      "type" : "DocumentReference",
      "profile" : "https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ReferenciaDocumental",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type",
        "documentation" : "ITI-67 Find Document References.\nPermite localizar referencias documentales mediante los parámetros\nde búsqueda definidos por IHE MHD y esta guía."
      }],
      "searchParam" : [{
        "name" : "_id",
        "type" : "token"
      },
      {
        "name" : "_lastupdated",
        "type" : "date"
      },
      {
        "name" : "author.given",
        "type" : "string"
      },
      {
        "name" : "author.family",
        "type" : "string"
      },
      {
        "name" : "category",
        "type" : "token"
      },
      {
        "name" : "creation",
        "type" : "date"
      },
      {
        "name" : "date",
        "type" : "date"
      },
      {
        "name" : "event",
        "type" : "token"
      },
      {
        "name" : "facility",
        "type" : "token"
      },
      {
        "name" : "format",
        "type" : "token"
      },
      {
        "name" : "identifier",
        "type" : "token"
      },
      {
        "name" : "patient",
        "type" : "reference"
      },
      {
        "name" : "patient.identifier",
        "type" : "token"
      },
      {
        "name" : "period",
        "type" : "date"
      },
      {
        "name" : "related",
        "type" : "reference"
      },
      {
        "name" : "security-label",
        "type" : "token"
      },
      {
        "name" : "setting",
        "type" : "token"
      },
      {
        "name" : "status",
        "type" : "token"
      },
      {
        "name" : "type",
        "type" : "token"
      }]
    },
    {
      "type" : "List",
      "profile" : "https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ListMhd",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type",
        "documentation" : "ITI-66 Find Document Lists.\nPermite consultar los SubmissionSet registrados utilizando\nel perfil ListMhd."
      }],
      "searchParam" : [{
        "name" : "_id",
        "type" : "token"
      },
      {
        "name" : "_lastupdated",
        "type" : "date"
      },
      {
        "name" : "code",
        "type" : "token"
      },
      {
        "name" : "date",
        "type" : "date"
      },
      {
        "name" : "identifier",
        "type" : "token"
      },
      {
        "name" : "patient",
        "type" : "reference"
      },
      {
        "name" : "patient.identifier",
        "type" : "token"
      },
      {
        "name" : "source.given",
        "type" : "string"
      },
      {
        "name" : "source.family",
        "type" : "string"
      },
      {
        "name" : "status",
        "type" : "token"
      },
      {
        "name" : "designationType",
        "type" : "token"
      },
      {
        "name" : "sourceId",
        "type" : "token"
      }]
    }],
    "interaction" : [{
      "code" : "transaction",
      "documentation" : "ITI-65 Provide Document Bundle.\n\nEl servidor SHALL aceptar un Bundle transaction conforme al perfil\nBundleMhd:\n\nhttps://hl7chile.cl/fhir/ig/mhd/StructureDefinition/BundleMhd"
    },
    {
      "code" : "search-system",
      "documentation" : "Búsqueda a nivel de sistema de acuerdo con las capacidades\ndefinidas para IHE MHD Document Responder."
    }]
  }]
}

```
