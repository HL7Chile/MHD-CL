# HL7.FHIR.CL.MHDIG\Categorías de Documento Clínico para DocumentReference - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Categorías de Documento Clínico para DocumentReference**

## ValueSet: Categorías de Documento Clínico para DocumentReference 

| | |
| :--- | :--- |
| *Official URL*:https://hl7chile.cl/fhir/ig/mhd/ValueSet/VSCategoriaDoc | *Version*:0.1.0 |
| Active as of 2026-10-22 | *Computable Name*:VSCategoriaDoc |
| *Other Identifiers:*OID:2.16.840.1.113883.2.22.40.14.48.1 | |

 
Categorías generales de documentos clínicos codificadas en LOINC para ser usadas en DocumentReference.category. 

 **References** 

* [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "VSCategoriaDoc",
  "url" : "https://hl7chile.cl/fhir/ig/mhd/ValueSet/VSCategoriaDoc",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.2.22.40.14.48.1"
  }],
  "version" : "0.1.0",
  "name" : "VSCategoriaDoc",
  "title" : "Categorías de Documento Clínico para DocumentReference",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-22T10:20:43-03:00",
  "publisher" : "Hl7 Chile",
  "contact" : [{
    "name" : "Hl7 Chile",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7chile.cl/"
    }]
  }],
  "description" : "Categorías generales de documentos clínicos codificadas en LOINC para ser usadas en DocumentReference.category.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "26436-6",
        "display" : "Laboratory studies (set)"
      },
      {
        "code" : "18726-0",
        "display" : "Radiology studies (set)"
      },
      {
        "code" : "11506-3",
        "display" : "Progress note"
      },
      {
        "code" : "18842-5",
        "display" : "Discharge summary"
      },
      {
        "code" : "60591-5",
        "display" : "Patient summary document"
      }]
    }]
  }
}

```
