# HL7.FHIR.CL.MHDIG\ListMhd - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ListMhd**

## Resource Profile: ListMhd 

| | |
| :--- | :--- |
| *Official URL*:https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ListMhd | *Version*:0.1.0 |
| Draft as of 2026-10-22 | *Computable Name*:ListMhd |
| *Other Identifiers:*OID:2.16.840.1.113883.2.22.40.14.42.2 | |

 
Perfil asociado al listado de documentos referenciados para HSI en un modelo MHD 

**Usages:**

* Use this Perfil: [BundleMhd](StructureDefinition-BundleMhd.md)
* Examples for this Perfil: [List/EjemploListMhd](List-EjemploListMhd.md)
* CapabilityStatements using this Perfil: [Capacidades para Cliente MHD](CapabilityStatement-MHDCliente.md) and [MHD Responder](CapabilityStatement-MHDResponder.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.fhir.cl.mhdig|current/StructureDefinition/StructureDefinition-ListMhd.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ListMhd.csv), [Excel](StructureDefinition-ListMhd.xlsx), [Schematron](StructureDefinition-ListMhd.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ListMhd",
  "url" : "https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ListMhd",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.2.22.40.14.42.2"
  }],
  "version" : "0.1.0",
  "name" : "ListMhd",
  "status" : "draft",
  "date" : "2026-10-22T10:20:43-03:00",
  "publisher" : "Hl7 Chile",
  "contact" : [{
    "name" : "Hl7 Chile",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7chile.cl/"
    }]
  }],
  "description" : "Perfil asociado al listado de documentos referenciados para HSI en un modelo MHD",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "SubmissionSet-Mapping",
    "uri" : "urn:ihe:iti:xds:submissionset",
    "name" : "XDS and MHD Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "List",
  "baseDefinition" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.SubmissionSet",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "List.subject",
      "path" : "List.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://hl7chile.cl/fhir/ig/clcore/StructureDefinition/CorePacienteCl"]
      }]
    },
    {
      "id" : "List.entry.item",
      "path" : "List.entry.item",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ReferenciaDocumental"]
      }]
    }]
  }
}

```
