# HL7.FHIR.CL.MHDIG\Inicio - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* **Inicio**

## Inicio

| | |
| :--- | :--- |
| *Official URL*:https://hl7chile.cl/fhir/ig/mhd/ImplementationGuide/hl7.fhir.cl.mhdig | *Version*:0.1.0 |
| Draft as of 2026-10-22 | *Computable Name*:MHDTransIGChile |
| *Other Identifiers:*OID:2.16.840.1.113883.2.22.40.14 | |

### Guía de Implementación MHD

#### Introducción

Esta Guía de Implementación define los requisitos para el intercambio de documentos clínicos mediante el estándar HL7® FHIR®, utilizando como base el perfil **Mobile access to Health Documents (MHD)** desarrollado por IHE.

La guía adapta los perfiles, actores y transacciones definidos por IHE MHD al contexto Chileno, incorporando los requisitos nacionales de identificación de pacientes, profesionales y organizaciones establecidos por la **Guía de Implementación Core de Chile (CL Core)**.

Su propósito es facilitar el registro, consulta y recuperación interoperable de documentos clínicos entre sistemas de información de salud.

#### Objetivo

El objetivo de esta guía es establecer una implementación común para:

* Registrar documentos clínicos y sus metadatos.
* Agrupar documentos dentro de un SubmissionSet.
* Consultar documentos utilizando parámetros normalizados.
* Recuperar documentos clínicos desde un repositorio.
* Identificar pacientes, profesionales y organizaciones de acuerdo con las definiciones nacionales.
* Facilitar la interoperabilidad entre sistemas clínicos, repositorios documentales y plataformas de intercambio de información sanitaria.

#### Alcance

Esta guía cubre el intercambio de documentos clínicos mediante recursos FHIR, incluyendo principalmente:

* Registro de metadatos documentales.
* Registro de conjuntos de documentos.
* Consulta de referencias documentales.
* Recuperación de documentos.
* Asociación de los documentos con pacientes, profesionales y organizaciones.
* Uso de terminologías y sistemas de identificación nacionales.

El contenido clínico del documento se encontrará almacenado en un repositorio externo. En estos casos, el recurso `DocumentReference` contiene la URL necesaria para acceder al documento.

#### Dependencias

Esta guía utiliza las siguientes Guías de Implementación como dependencias:

##### IHE Mobile access to Health Documents (MHD)

IHE MHD proporciona los perfiles, actores y transacciones necesarios para compartir documentos clínicos utilizando recursos y operaciones FHIR.

Esta guía reutiliza y restringe los perfiles definidos por IHE MHD, principalmente:

* `DocumentReference` para representar los metadatos del documento.
* `List` para representar un SubmissionSet.
* `Bundle` de tipo `transaction` para registrar conjuntamente los recursos.
* Operaciones de búsqueda para consultar documentos y conjuntos documentales.
* Mecanismos de recuperación del contenido documental.

La implementación local mantiene la compatibilidad con las transacciones definidas por IHE MHD.

##### Core Chilena (CL Core)

CL Core proporciona las definiciones nacionales utilizadas para representar las entidades fundamentales del sistema de salud chileno.

Esta guía utiliza perfiles y terminologías de Core AR para:

* Identificación de pacientes.
* Identificación de profesionales de salud.
* Identificación de organizaciones y establecimientos.
* Representación de datos demográficos.
* Uso de sistemas de identificación y terminologías nacionales.

Cuando un recurso definido por IHE MHD referencia a un paciente, profesional u organización, se deben utilizar los perfiles correspondientes definidos por Core AR, siempre que sean aplicables.

#### Relación entre las guías

La relación entre las Guías de Implementación puede resumirse de la siguiente manera:

* **HL7 FHIR R4** proporciona el estándar base de interoperabilidad.
* **International Patient Summary** proporciona un resumen de la historia clínica del paciente.
* **CL Core** define los requisitos nacionales para las entidades fundamentales.
* **Resumen Clínico de Chile** proporciona una chilenización del proyecto de IPS, tomando la core de Chile como base.
* **IHE MHD** define el modelo internacional para el intercambio de documentos clínicos.
* **Esta guía** combina y restringe ambos conjuntos de definiciones para su aplicación en el contexto chileno.

graph TD FHIR["HL7 FHIR R4"] IPS["HL7 FHIR IPS"] CORE["HL7 Chile Core"] CLIPS["Resumen Clínico de Chile"] MHD["IHE MHD"] LOCAL["Guía MHD Chile"] FHIR --> CORE FHIR --> IPS FHIR --> MHD CORE --> CLIPS IPS --> CLIPS CLIPS --> LOCAL MHD --> LOCAL

Los requerimientos de conformidad establecen las funcionalidades esperadas para aplicaciones cliente y servidor, identificando los perfiles y las interacciones que deben implementar.

### Dependencias












### Parametros de Expansión

### Analisis de versiones cruzadas

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.cl.mhdig.r4)](package.r4.tgz) and [R4B (hl7.fhir.cl.mhdig.r4b)](package.r4b.tgz) are available.

### Perfiles globales

*There are no Global profiles defined*

### Declaracion de propiedad intelectual

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [BundleMhd](StructureDefinition-BundleMhd.md), [ListMhd](StructureDefinition-ListMhd.md)... Show 6 more, [MHDCliente](CapabilityStatement-MHDCliente.md), [MHDResponder](CapabilityStatement-MHDResponder.md), [MHDTransIGChile](index.md), [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md), [VSCategoriaDoc](ValueSet-VSCategoriaDoc.md) and [VSTipoDocumento](ValueSet-VSTipoDocumento.md)


* Most of the information on the CDC and ATSDR websites is not subject to copyright, is in the public domain, and may be freely used or reproduced without obtaining copyright permission. For information and exceptions regarding use of CDC material please see [https://www.cdc.gov/other/agencymaterials.html](https://www.cdc.gov/other/agencymaterials.html) 

* [Vaccine Administered Code Set (CVX)](http://terminology.hl7.org/6.5.0/CodeSystem-CVX.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md), [Bundle/bundle-mhd-referencia-documental-ejemplo](Bundle-bundle-mhd-referencia-documental-ejemplo.md)... Show 4 more, [DocumentReference/ReferDocEjemplo](DocumentReference-ReferDocEjemplo.md), [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md), [VSCategoriaDoc](ValueSet-VSCategoriaDoc.md) and [VSTipoDocumento](ValueSet-VSTipoDocumento.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.4.0/CodeSystem-allergyintolerance-clinical.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.4.0/CodeSystem-allergyintolerance-verification.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.4.0/CodeSystem-condition-clinical.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.4.0/CodeSystem-condition-ver-status.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md)


* Usado con el permiso de HL7 International, todos los derechos resevados en los Licencias de HL7 Internacional.

* [Tipo Identificador](https://hl7chile.cl/fhir/ig/clcore/1.9.4/CodeSystem-CSTipoIdentificador.html): [Bundle/BundleDocumentoIpsEjemplo](Bundle-BundleDocumentoIpsEjemplo.md) and [Practitioner/PrestadorCLInline](Practitioner-PrestadorCLInline.md)




## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "hl7.fhir.cl.mhdig",
  "language" : "es",
  "url" : "https://hl7chile.cl/fhir/ig/mhd/ImplementationGuide/hl7.fhir.cl.mhdig",
  "version" : "0.1.0",
  "name" : "MHDTransIGChile",
  "title" : "Guía MHD para el Intercambio de Información de Salud en Chile",
  "status" : "draft",
  "date" : "2026-10-22T10:20:43-03:00",
  "publisher" : "Hl7 Chile",
  "contact" : [{
    "name" : "Hl7 Chile",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7chile.cl/"
    }]
  }],
  "description" : "Esta guía de implementación describe los esquemas de transacciones FHIR MHD para el intercambio de información de salud en Chile, asociado a las guías IHE MHD y Core-AR.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "packageId" : "hl7.fhir.cl.mhdig",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "hl7_fhir_cl_clcore",
    "uri" : "https://hl7chile.cl/fhir/ig/clcore/ImplementationGuide/hl7.fhir.cl.clcore",
    "packageId" : "hl7.fhir.cl.clcore",
    "version" : "1.9.4"
  },
  {
    "id" : "hl7_fhir_cl_clips",
    "uri" : "https://hl7chile.cl/fhir/ig/clips/ImplementationGuide/hl7.fhir.cl.clips",
    "packageId" : "hl7.fhir.cl.clips",
    "version" : "current"
  },
  {
    "id" : "ihe_iti_mhd",
    "uri" : "https://profiles.ihe.net/ITI/MHD/ImplementationGuide/ihe.iti.mhd",
    "packageId" : "ihe.iti.mhd",
    "version" : "4.2.5"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2026+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "auto-oid-root"
      },
      {
        "url" : "value",
        "valueString" : "2.16.840.1.113883.2.22.40.14"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://hl7chile.cl/fhir/ig/mhd/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-BundleDocumentoIpsEjemplo.html"
      }],
      "reference" : {
        "reference" : "Bundle/BundleDocumentoIpsEjemplo"
      },
      "name" : "Bundle documento IPS Chile de ejemplo",
      "description" : "Bundle de tipo document: Composition como primera entrada, seguido del paciente, el autor y los recursos clínicos referenciados por las secciones.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-bundle-mhd-referencia-documental-ejemplo.html"
      }],
      "reference" : {
        "reference" : "Bundle/bundle-mhd-referencia-documental-ejemplo"
      },
      "name" : "Bundle MHD con referencia documental de ejemplo",
      "description" : "Bundle transaction que vincula el DocumentReference generado previamente.",
      "exampleCanonical" : "https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/BundleMhd"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BundleMhd.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleMhd"
      },
      "name" : "BundleMhd",
      "description" : "Perfil asociado al bundle de transacciones MHD, considerando la asociación de documentos de tipo IPS, referenciados a la Guía Core Argentna AR.FHIR.CORE",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-MHDCliente.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/MHDCliente"
      },
      "name" : "Capacidades para Cliente MHD",
      "description" : "CapabilityStatement que define las capacidades requeridas para los\nsistemas cliente que interactúan con el MHD Responder definido por\nesta guía.\n\nEl cliente implementa las funciones de Document Source y Document\nConsumer definidas por IHE MHD 4.2.2, adaptadas a los perfiles y\nrestricciones de esta implementación local.\n\nEl cliente puede publicar documentos mediante ITI-65, consultar\nSubmissionSets mediante ITI-66, localizar referencias documentales\nmediante ITI-67 y recuperar documentos mediante ITI-68.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSCategoriaDoc.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSCategoriaDoc"
      },
      "name" : "Categorías de Documento Clínico para DocumentReference",
      "description" : "Categorías generales de documentos clínicos codificadas en LOINC para ser usadas en DocumentReference.category.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-EjemploListMhd.html"
      }],
      "reference" : {
        "reference" : "List/EjemploListMhd"
      },
      "name" : "Ejemplo mínimo de List MHD",
      "description" : "Ejemplo mínimo de List como SubmissionSet MHD con una referencia documental.",
      "exampleCanonical" : "https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ListMhd"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ListMhd.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ListMhd"
      },
      "name" : "ListMhd",
      "description" : "Perfil asociado al listado de documentos referenciados para HSI en un modelo MHD",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-MHDResponder.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/MHDResponder"
      },
      "name" : "MHD Responder",
      "description" : "CapabilityStatement que define las capacidades requeridas para un servidor\nMHD conforme a la Guía MHD para HSI.\n\nEl servidor implementa las funciones de Document Recipient y Document\nResponder definidas por IHE MHD 4.2.2, adaptadas a los perfiles locales\nde esta guía.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-Paciente-Interno.html"
      }],
      "reference" : {
        "reference" : "Patient/Paciente-Interno"
      },
      "name" : "Paciente-Interno",
      "description" : "Ejemplo de paciente Chileno conforme al perfil PacienteCLIps, con rut y nombre oficial.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-PrestadorCLInline.html"
      }],
      "reference" : {
        "reference" : "Practitioner/PrestadorCLInline"
      },
      "name" : "PrestadorCLInline",
      "description" : "Ejemplo inline de profesional argentino conforme al perfil PrestadorArg.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ReferDocEjemplo.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ReferDocEjemplo"
      },
      "name" : "Referencia documental mínima para DocumentoArg",
      "description" : "Ejemplo de DocumentReference MHD que referencia un documento clínico FHIR DocumentoArg.",
      "exampleCanonical" : "https://hl7chile.cl/fhir/ig/mhd/StructureDefinition/ReferenciaDocumental"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ReferenciaDocumental.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ReferenciaDocumental"
      },
      "name" : "ReferenciaDocumental",
      "description" : "Perfil asociado al la refetrencia documental para HSI en un modelo MHD, consderado para transacciones asociadas a una ITI-65 e ITI-67. Se considera en el perfil la asociación de documentos de tipo IPS, referenciados a la Guía Core Argentna AR.FHIR.CORE",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-VSTipoDocumento.html"
      }],
      "reference" : {
        "reference" : "ValueSet/VSTipoDocumento"
      },
      "name" : "Tipos de Documento Clínico para DocumentReference",
      "description" : "Tipos documentales clínicos codificados en LOINC para ser usados en DocumentReference.type.",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Inicio",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "intercambio.html"
        }],
        "nameUrl" : "intercambio.html",
        "title" : "Esquemas de transacciones FHIR MHD",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "transacciones-mhd.html"
        }],
        "nameUrl" : "transacciones-mhd.html",
        "title" : "Transacciones asociadas a MHD",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "seguridad.html"
        }],
        "nameUrl" : "seguridad.html",
        "title" : "Aspectos de Seguridad",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "cambios.html"
        }],
        "nameUrl" : "cambios.html",
        "title" : "Historial de Versiones",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
