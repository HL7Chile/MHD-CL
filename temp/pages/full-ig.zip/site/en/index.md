# HL7.FHIR.CL.MHDIG\ - FHIR v4.0.1

## Inicio

### Guía de Implementación MHD

#### Introducción

Esta Guía de Implementación define los requisitos para el intercambio de documentos clínicos mediante el estándar HL7® FHIR®, utilizando como base el perfil **Mobile access to Health Documents (MHD)** desarrollado por IHE.

La guía adapta los perfiles, actores y transacciones definidos por IHE MHD al contexto argentino, incorporando los requisitos nacionales de identificación de pacientes, profesionales y organizaciones establecidos por la **Guía de Implementación Core Argentina (Core AR)**.

Su propósito es facilitar el registro, consulta y recuperación interoperable de documentos clínicos entre sistemas de información de salud.

#### Objetivo

El objetivo de esta guía es establecer una implementación común para:

* Registrar documentos clínicos y sus metadatos.
* Agrupar documentos dentro de un SubmissionSet.
* Consultar documentos utilizando parámetros normalizados.
* Recuperar documentos clínicos desde un repositorio.
* Identificar pacientes, profesionales y organizaciones de acuerdo con las definiciones nacionales.
* Facilitar la interoperabilidad entre sistemas clínicos, repositorios documentales y plataformas de intercambio de información sanitaria.

#### Alcance

Esta guía cubre el intercambio de documentos clínicos mediante recursos FHIR, incluyendo principalmente:

* Registro de metadatos documentales.
* Registro de conjuntos de documentos.
* Consulta de referencias documentales.
* Recuperación de documentos.
* Asociación de los documentos con pacientes, profesionales y organizaciones.
* Uso de terminologías y sistemas de identificación nacionales.

El contenido clínico del documento se encontrará almacenado en un repositorio externo. En estos casos, el recurso `DocumentReference` contiene la URL necesaria para acceder al documento.

#### Dependencias

Esta guía utiliza las siguientes Guías de Implementación como dependencias:

##### IHE Mobile access to Health Documents (MHD)

IHE MHD proporciona los perfiles, actores y transacciones necesarios para compartir documentos clínicos utilizando recursos y operaciones FHIR.

Esta guía reutiliza y restringe los perfiles definidos por IHE MHD, principalmente:

* `DocumentReference` para representar los metadatos del documento.
* `List` para representar un SubmissionSet.
* `Bundle` de tipo `transaction` para registrar conjuntamente los recursos.
* Operaciones de búsqueda para consultar documentos y conjuntos documentales.
* Mecanismos de recuperación del contenido documental.

La implementación local mantiene la compatibilidad con las transacciones definidas por IHE MHD.

##### Core Argentina (Core AR)

Core AR proporciona las definiciones nacionales utilizadas para representar las entidades fundamentales del sistema de salud argentino.

Esta guía utiliza perfiles y terminologías de Core AR para:

* Identificación de pacientes.
* Identificación de profesionales de salud.
* Identificación de organizaciones y establecimientos.
* Representación de datos demográficos.
* Uso de sistemas de identificación y terminologías nacionales.

Cuando un recurso definido por IHE MHD referencia a un paciente, profesional u organización, se deben utilizar los perfiles correspondientes definidos por Core AR, siempre que sean aplicables.

#### Relación entre las guías

La relación entre las Guías de Implementación puede resumirse de la siguiente manera:

* **HL7 FHIR R4** proporciona el estándar base de interoperabilidad.
* **Core AR** define los requisitos nacionales para las entidades fundamentales.
* **IHE MHD** define el modelo internacional para el intercambio de documentos clínicos.
* **Esta guía** combina y restringe ambos conjuntos de definiciones para su aplicación en el contexto argentino.

```mermaid flowchart TB FHIR["HL7 FHIR R4"] CORE["Core Argentina"] MHD["IHE MHD"] LOCAL["Guía MHD Argentina"]

```
FHIR --> CORE
FHIR --> MHD
CORE --> LOCAL
MHD --> LOCAL

```

Los requerimientos de conformidad establecen las funcionalidades esperadas para aplicaciones cliente y servidor, identificando los perfiles y las interacciones que deben implementar.

### Dependencias




























### Parametros de Expansión

### Analisis de versiones cruzadas

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.cl.mhdig.r4)](../package.r4.tgz) and [R4B (hl7.fhir.cl.mhdig.r4b)](../package.r4b.tgz) are available.

### Perfiles globales

*There are no Global profiles defined*

### Declaracion de propiedad intelectual

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [BundleMhd](StructureDefinition-BundleMhd.md), [ListMhd](StructureDefinition-ListMhd.md)... Show 6 more, [MHDCliente](CapabilityStatement-MHDCliente.md), [MHDResponder](CapabilityStatement-MHDResponder.md), [MHDTransIGChile](index.md), [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md), [VSCategoriaDoc](ValueSet-VSCategoriaDoc.md) and [VSTipoDocumento](ValueSet-VSTipoDocumento.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md), [VSCategoriaDoc](ValueSet-VSCategoriaDoc.md) and [VSTipoDocumento](ValueSet-VSTipoDocumento.md)


