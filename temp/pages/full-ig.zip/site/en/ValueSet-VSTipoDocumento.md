# HL7.FHIR.CL.MHDIG\ - FHIR v4.0.1

## ValueSet: Tipos de Documento Clínico para DocumentReference 

 **References** 

* [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "VSTipoDocumento",
  "url" : "https://hl7chile.cl/fhir/ig/mhd/ValueSet/VSTipoDocumento",
  "version" : "0.1.0",
  "name" : "VSTipoDocumento",
  "title" : "Tipos de Documento Clínico para DocumentReference",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-15T12:40:59-03:00",
  "publisher" : "Hl7 Chile",
  "contact" : [{
    "name" : "Hl7 Chile",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7chile.cl/"
    }]
  }],
  "description" : "Tipos documentales clínicos codificados en LOINC para ser usados en DocumentReference.type.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "11502-2",
        "display" : "Laboratory report"
      },
      {
        "code" : "18748-4",
        "display" : "Diagnostic imaging study"
      },
      {
        "code" : "34131-3",
        "display" : "Outpatient Progress note"
      },
      {
        "code" : "34105-7",
        "display" : "Hospital Discharge summary"
      },
      {
        "code" : "59258-4",
        "display" : "Emergency department Discharge summary"
      },
      {
        "code" : "34133-9",
        "display" : "Summary of episode note"
      }]
    }]
  }
}

```
