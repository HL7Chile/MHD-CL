# HL7.FHIR.CL.MHDIG\ - FHIR v4.0.1

## ValueSet: Categorías de Documento Clínico para DocumentReference 

 **References** 

* [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "VSCategoriaDoc",
  "url" : "https://hl7chile.cl/fhir/ig/mhd/ValueSet/VSCategoriaDoc",
  "version" : "0.1.0",
  "name" : "VSCategoriaDoc",
  "title" : "Categorías de Documento Clínico para DocumentReference",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-15T12:40:59-03:00",
  "publisher" : "Hl7 Chile",
  "contact" : [{
    "name" : "Hl7 Chile",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7chile.cl/"
    }]
  }],
  "description" : "Categorías generales de documentos clínicos codificadas en LOINC para ser usadas en DocumentReference.category.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "26436-6",
        "display" : "Laboratory studies (set)"
      },
      {
        "code" : "18726-0",
        "display" : "Radiology studies (set)"
      },
      {
        "code" : "11506-3",
        "display" : "Progress note"
      },
      {
        "code" : "18842-5",
        "display" : "Discharge summary"
      },
      {
        "code" : "60591-5",
        "display" : "Patient summary document"
      }]
    }]
  }
}

```
