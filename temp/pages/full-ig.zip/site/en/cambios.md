# HL7.FHIR.CL.MHDIG\ - FHIR v4.0.1

## Historial de Versiones

### Versión 0.1.0

Se crea la primera adaptación nacional de MHD.

