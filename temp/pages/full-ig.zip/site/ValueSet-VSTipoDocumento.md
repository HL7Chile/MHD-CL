# HL7.FHIR.CL.MHDIG\Tipos de Documento Clínico para DocumentReference - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Tipos de Documento Clínico para DocumentReference**

## ValueSet: Tipos de Documento Clínico para DocumentReference 

| | |
| :--- | :--- |
| *Official URL*:https://hl7chile.cl/fhir/ig/mhd/ValueSet/VSTipoDocumento | *Version*:0.1.0 |
| Active as of 2026-10-22 | *Computable Name*:VSTipoDocumento |
| *Other Identifiers:*OID:2.16.840.1.113883.2.22.40.14.48.2 | |

 
Tipos documentales clínicos codificados en LOINC para ser usados en DocumentReference.type. 

 **References** 

* [ReferenciaDocumental](StructureDefinition-ReferenciaDocumental.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "VSTipoDocumento",
  "url" : "https://hl7chile.cl/fhir/ig/mhd/ValueSet/VSTipoDocumento",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.2.22.40.14.48.2"
  }],
  "version" : "0.1.0",
  "name" : "VSTipoDocumento",
  "title" : "Tipos de Documento Clínico para DocumentReference",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-22T10:20:43-03:00",
  "publisher" : "Hl7 Chile",
  "contact" : [{
    "name" : "Hl7 Chile",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7chile.cl/"
    }]
  }],
  "description" : "Tipos documentales clínicos codificados en LOINC para ser usados en DocumentReference.type.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "11502-2",
        "display" : "Laboratory report"
      },
      {
        "code" : "18748-4",
        "display" : "Diagnostic imaging study"
      },
      {
        "code" : "34131-3",
        "display" : "Outpatient Progress note"
      },
      {
        "code" : "34105-7",
        "display" : "Hospital Discharge summary"
      },
      {
        "code" : "59258-4",
        "display" : "Emergency department Discharge summary"
      },
      {
        "code" : "34133-9",
        "display" : "Summary of episode note"
      }]
    }]
  }
}

```
