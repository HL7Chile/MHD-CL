# HL7.FHIR.CL.MHDIG\Bundle documento IPS Chile de ejemplo - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle documento IPS Chile de ejemplo**

## Example Bundle: Bundle documento IPS Chile de ejemplo



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundleDocumentoIpsEjemplo",
  "meta" : {
    "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Bundle-documento-ips-cl"]
  },
  "identifier" : {
    "system" : "http://hsisalud.org/documentos",
    "value" : "DOC-IPS-CL-0001"
  },
  "type" : "document",
  "timestamp" : "2026-07-06T10:30:00-03:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0001",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "ComposicionIps-Ejemplo",
      "meta" : {
        "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Composition-cl-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_ComposicionIps-Ejemplo\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composición ComposicionIps-Ejemplo</b></p><a name=\"ComposicionIps-Ejemplo\"> </a><a name=\"hcComposicionIps-Ejemplo\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-Composition-cl-ips.html\">Documento</a></p></div><p><b>identifier</b>: <code>http://hsisalud.org/documentos</code>/DOC-IPS-CL-0001</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 60591-5}\">Patient summary Document</span></p><p><b>date</b>: 2026-07-06 10:30:00-0300</p><p><b>author</b>: <a href=\"Bundle-BundleDocumentoIpsEjemplo.html#urn-uuid-5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0002\">María Laura Gómez Perez</a></p><p><b>title</b>: Resumen Internacional del Paciente - Chile</p></div>"
      },
      "identifier" : {
        "system" : "http://hsisalud.org/documentos",
        "value" : "DOC-IPS-CL-0001"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60591-5",
          "display" : "Patient summary Document"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:991a7102-d221-498d-9157-c4192934e3b7",
        "display" : "Pablo Fernandez Perez"
      },
      "date" : "2026-07-06T10:30:00-03:00",
      "author" : [{
        "reference" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0002",
        "display" : "María Laura Gómez Perez"
      }],
      "title" : "Resumen Internacional del Paciente - Chile",
      "section" : [{
        "title" : "Inmunizaciones",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11369-6",
            "display" : "History of Immunization note"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Registro mínimo de inmunización.</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0003",
          "display" : "Inmunización COVID-19 registrada"
        }]
      },
      {
        "title" : "Problemas y condiciones",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11450-4",
            "display" : "Problem list - Reported"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Condición clínica registrada.</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0004"
        }]
      },
      {
        "title" : "Medicación",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "10160-0",
            "display" : "History of Medication use Narrative"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Medicación activa registrada.</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0005"
        }]
      },
      {
        "title" : "Alergias e intolerancias",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48765-2",
            "display" : "Allergies and adverse reactions Document"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Alergia registrada.</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0006"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:991a7102-d221-498d-9157-c4192934e3b7",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "Paciente-Interno",
      "meta" : {
        "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Paciente-cl-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_Paciente-Interno\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Paciente Paciente-Interno</b></p><a name=\"Paciente-Interno\"> </a><a name=\"hcPaciente-Interno\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-Paciente-cl-ips.html\">Paciente</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Pablo Fernandez Perez(official) Male, DoB: 1912-06-12 ( https://www.registrocivil.cl/run#99999999-9 (use: official))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">ph: 1141233100</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://www.registrocivil.cl/run",
        "value" : "99999999-9"
      }],
      "active" : true,
      "name" : [{
        "use" : "official",
        "text" : "Pablo Fernandez Perez",
        "family" : "Fernandez",
        "_family" : {
          "extension" : [{
            "url" : "https://hl7chile.cl/fhir/ig/clcore/StructureDefinition/SegundoApellido",
            "valueString" : "Perez"
          }]
        },
        "given" : ["Pablo"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "1141233100"
      }],
      "gender" : "male",
      "birthDate" : "1912-06-12"
    }
  },
  {
    "fullUrl" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0002",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "PrestadorCLInline",
      "meta" : {
        "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Prestador-cl-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_PrestadorCLInline\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practicante / Profesional PrestadorCLInline</b></p><a name=\"PrestadorCLInline\"> </a><a name=\"hcPrestadorCLInline\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-Prestador-cl-ips.html\">Prestador Individual</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">María Laura Gómez (official) (RNPI: 987654 (use: usual))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td>true</td><td style=\"background-color: #f3f5da\" title=\"Administrative gender\">Gender:</td><td>Female</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Date of birth\">Date of Birth:</td><td colspan=\"3\">1980-05-12</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\">RUN/12345678-K (use: official)</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Practitioner\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+5695555-1234\">+56 9 5555-1234</a></li><li><a href=\"mailto:maria.perez@example.org\">maria.perez@example.org</a></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Certification, licensure, or training pertaining to the provision of care\">Qualification:</td><td colspan=\"3\"><span title=\"Codes:\">Médica</span><ul><li>Identifier: cert</li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "https://hl7chile.cl/fhir/ig/clcore/CodeSystem/CSTipoIdentificador",
            "code" : "01"
          }]
        },
        "system" : "https://www.registrocivil.cl/run",
        "value" : "12345678-K"
      },
      {
        "use" : "usual",
        "type" : {
          "coding" : [{
            "system" : "https://hl7chile.cl/fhir/ig/clcore/CodeSystem/CSTipoIdentificador",
            "code" : "13"
          }]
        },
        "system" : "https://rnpi.superdesalud.gob.cl/#",
        "value" : "987654"
      }],
      "active" : true,
      "name" : [{
        "use" : "official",
        "family" : "Gómez",
        "_family" : {
          "extension" : [{
            "url" : "https://hl7chile.cl/fhir/ig/clcore/StructureDefinition/SegundoApellido",
            "valueString" : "Perez"
          }]
        },
        "given" : ["María", "Laura"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+56 9 5555-1234",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "maria.perez@example.org",
        "use" : "work"
      }],
      "gender" : "female",
      "birthDate" : "1980-05-12",
      "qualification" : [{
        "identifier" : [{
          "value" : "cert"
        }],
        "code" : {
          "text" : "Médica"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0003",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "inmunizacion-1",
      "meta" : {
        "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Inmunizacion-cl-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_inmunizacion-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Inmunización inmunizacion-1</b></p><a name=\"inmunizacion-1\"> </a><a name=\"hcinmunizacion-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-Inmunizacion-cl-ips.html\">Inmunización</a></p></div><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/cvx 207}\">COVID-19, mRNA, LNP-S, PF, 100 mcg/0.5mL dose or 50 mcg/0.25mL dose</span></p><p><b>patient</b>: <a href=\"Bundle-BundleDocumentoIpsEjemplo.html#urn-uuid-991a7102-d221-498d-9157-c4192934e3b7\">Pablo Fernandez Perez</a></p><p><b>occurrence</b>: 2024-05-10</p><p><b>primarySource</b>: true</p><p><b>location</b>: Centro de Salud de Ejemplo (Identifier: <code>http://refes.msal.gob.ar</code>/REFES-0001)</p><p><b>lotNumber</b>: L240510A</p><p><b>reasonCode</b>: <span title=\"Codes:\">Calendario nacional de vacunación</span></p><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>DoseNumber[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td></tr></table></div>"
      },
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/cvx",
          "code" : "207",
          "display" : "COVID-19, mRNA, LNP-S, PF, 100 mcg/0.5mL dose or 50 mcg/0.25mL dose"
        }]
      },
      "patient" : {
        "reference" : "urn:uuid:991a7102-d221-498d-9157-c4192934e3b7",
        "display" : "Pablo Fernandez Perez"
      },
      "occurrenceDateTime" : "2024-05-10",
      "primarySource" : true,
      "location" : {
        "identifier" : {
          "system" : "http://refes.msal.gob.ar",
          "value" : "REFES-0001"
        },
        "display" : "Centro de Salud de Ejemplo"
      },
      "lotNumber" : "L240510A",
      "reasonCode" : [{
        "text" : "Calendario nacional de vacunación"
      }],
      "protocolApplied" : [{
        "doseNumberPositiveInt" : 1
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0004",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "condicion-1",
      "meta" : {
        "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/Condition-cl-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_condicion-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condición condicion-1</b></p><a name=\"condicion-1\"> </a><a name=\"hccondicion-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-Condition-cl-ips.html\">Condición</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 38341003}\">Hypertensive disorder, systemic arterial</span></p><p><b>subject</b>: <a href=\"Bundle-BundleDocumentoIpsEjemplo.html#urn-uuid-991a7102-d221-498d-9157-c4192934e3b7\">Pablo Fernandez Perez</a></p><p><b>onset</b>: 2020-01-01</p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "38341003",
          "display" : "Hypertensive disorder, systemic arterial"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:991a7102-d221-498d-9157-c4192934e3b7",
        "display" : "Pablo Fernandez Perez"
      },
      "onsetDateTime" : "2020-01-01"
    }
  },
  {
    "fullUrl" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0005",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "medicacion-1",
      "meta" : {
        "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/RegMedicamentos-cl-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_medicacion-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResumenMedicación /ResumenMedicamento medicacion-1</b></p><a name=\"medicacion-1\"> </a><a name=\"hcmedicacion-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-RegMedicamentos-cl-ips.html\">Declaración de medicación</a></p></div><p><b>status</b>: Active</p><p><b>medication</b>: <span title=\"Codes:\">Amlodipina 5 mg comprimido</span></p><p><b>subject</b>: <a href=\"Bundle-BundleDocumentoIpsEjemplo.html#urn-uuid-991a7102-d221-498d-9157-c4192934e3b7\">Pablo Fernandez Perez</a></p><p><b>effective</b>: 2026-07-06</p></div>"
      },
      "status" : "active",
      "medicationCodeableConcept" : {
        "text" : "Amlodipina 5 mg comprimido"
      },
      "subject" : {
        "reference" : "urn:uuid:991a7102-d221-498d-9157-c4192934e3b7",
        "display" : "Pablo Fernandez Perez"
      },
      "effectiveDateTime" : "2026-07-06"
    }
  },
  {
    "fullUrl" : "urn:uuid:5e1c2f0a-7b0d-4c55-9a43-0c1f6a1d0006",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "alergia-1",
      "meta" : {
        "profile" : ["https://hl7chile.cl/fhir/ig/clips/StructureDefinition/AllergiaInt-cl-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AllergyIntolerance_alergia-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AllergiaIntolerancia alergia-1</b></p><a name=\"alergia-1\"> </a><a name=\"hcalergia-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"https://build.fhir.org/ig/HL7Chile/IPS-CL/StructureDefinition-AllergiaInt-cl-ips.html\">Alergias e Intolerancias</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-verification confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 91936005}\">Allergy to penicillin</span></p><p><b>patient</b>: <a href=\"Bundle-BundleDocumentoIpsEjemplo.html#urn-uuid-991a7102-d221-498d-9157-c4192934e3b7\">Pablo Fernandez Perez</a></p><p><b>onset</b>: 2018-03-15</p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "91936005",
          "display" : "Allergy to penicillin"
        }]
      },
      "patient" : {
        "reference" : "urn:uuid:991a7102-d221-498d-9157-c4192934e3b7",
        "display" : "Pablo Fernandez Perez"
      },
      "onsetDateTime" : "2018-03-15"
    }
  }]
}

```
