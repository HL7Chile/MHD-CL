window.artifactsTableData = {
  "en": {
    "labels": {
      "type":        "Type",
      "category":    "Category",
      "useGrouping": "Use grouping",
      "clearAll":      "Clear all",
      "linkToSection": "Link to this section"
    },
    "groupDescriptions": {
      "-dyn-capabilitystatement": "<p>The following artifacts define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide.  Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.</p>\n"
      ,"-str-profile": "<p>These define constraints on FHIR resources for systems conforming to this implementation guide.</p>\n"
      ,"-term-valueset": "<p>These define sets of codes used by systems conforming to this implementation guide.</p>\n"
    },
    "rows": [
      { "p":1, "gid":"-dyn-capabilitystatement", "g":"Behavior: Capability Statements", "n":"Capacidades para Cliente MHD", "i":"MHDCliente", "t":"CapabilityStatement", "u":"CapabilityStatement-MHDCliente.html", "r":"CapabilityStatement/MHDCliente", "d":"<p>CapabilityStatement que define las capacidades requeridas para los\nsistemas cliente que interactúan con el MHD Responder definido por\nesta guía.</p>\n\n<p>El cliente implementa las funciones de Document Source y Document\nConsumer definidas por IHE MHD 4.2.2, adaptadas a los perfiles y\nrestricciones de esta implementación local.</p>\n\n<p>El cliente puede publicar documentos mediante ITI-65, consultar\nSubmissionSets mediante ITI-66, localizar referencias documentales\nmediante ITI-67 y recuperar documentos mediante ITI-68.</p>" },
      { "p":1, "gid":"-dyn-capabilitystatement", "g":"Behavior: Capability Statements", "n":"MHD Responder", "i":"MHDResponder", "t":"CapabilityStatement", "u":"CapabilityStatement-MHDResponder.html", "r":"CapabilityStatement/MHDResponder", "d":"<p>CapabilityStatement que define las capacidades requeridas para un servidor\nMHD conforme a la Guía MHD para HSI.</p>\n\n<p>El servidor implementa las funciones de Document Recipient y Document\nResponder definidas por IHE MHD 4.2.2, adaptadas a los perfiles locales\nde esta guía.</p>" },
      { "p":2, "gid":"-str-profile", "g":"Structures: Resource Profiles", "n":"BundleMhd", "i":"BundleMhd", "t":"StructureDefinition", "u":"StructureDefinition-BundleMhd.html", "r":"StructureDefinition/BundleMhd", "d":"<p>Perfil asociado al bundle de transacciones MHD, considerando la asociación de documentos de tipo IPS, referenciados a la Guía Core Argentna AR.FHIR.CORE</p>" },
      { "p":2, "gid":"-str-profile", "g":"Structures: Resource Profiles", "n":"ListMhd", "i":"ListMhd", "t":"StructureDefinition", "u":"StructureDefinition-ListMhd.html", "r":"StructureDefinition/ListMhd", "d":"<p>Perfil asociado al listado de documentos referenciados para HSI en un modelo MHD</p>" },
      { "p":2, "gid":"-str-profile", "g":"Structures: Resource Profiles", "n":"ReferenciaDocumental", "i":"ReferenciaDocumental", "t":"StructureDefinition", "u":"StructureDefinition-ReferenciaDocumental.html", "r":"StructureDefinition/ReferenciaDocumental", "d":"<p>Perfil asociado al la refetrencia documental para HSI en un modelo MHD, consderado para transacciones asociadas a una ITI-65 e ITI-67. Se considera en el perfil la asociación de documentos de tipo IPS, referenciados a la Guía Core Argentna AR.FHIR.CORE</p>" },
      { "p":3, "gid":"-term-valueset", "g":"Terminology: Value Sets", "n":"Categorías de Documento Clínico para DocumentReference", "i":"VSCategoriaDoc", "t":"ValueSet", "u":"ValueSet-VSCategoriaDoc.html", "r":"ValueSet/VSCategoriaDoc", "d":"<p>Categorías generales de documentos clínicos codificadas en LOINC para ser usadas en DocumentReference.category.</p>" },
      { "p":3, "gid":"-term-valueset", "g":"Terminology: Value Sets", "n":"Tipos de Documento Clínico para DocumentReference", "i":"VSTipoDocumento", "t":"ValueSet", "u":"ValueSet-VSTipoDocumento.html", "r":"ValueSet/VSTipoDocumento", "d":"<p>Tipos documentales clínicos codificados en LOINC para ser usados en DocumentReference.type.</p>" }
    ]
  }
};
