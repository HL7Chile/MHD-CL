# HL7.FHIR.CL.MHDIG\ - FHIR v4.0.1

## Artifacts Summary

